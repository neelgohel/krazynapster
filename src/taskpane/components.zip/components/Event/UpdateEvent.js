import * as React from "react";
import { Button } from "office-ui-fabric-react";
import { updateEventOnMagnifi } from "../../api/index"

const UpdateEvent = (props) => {
  const updateEvent = () => {
    const { getMeetingData } = props; 
    getMeetingData(updateMagnifiEvent);
  }

  const updateMagnifiEvent = (meetingData) => {
    console.log('meetingData', meetingData);
    const {  startLoader, stopLoader, setError, clearError } = props;
    startLoader();
    updateEventOnMagnifi(meetingData).then( response => {
        if(response.status == 200){
          return response.json()
        } else if (response.status == 404) {
          setError('Unable to find meeting on magnifi');
        } else {
          console.log('Error in', response);
        }
      }).then( data => {
        if(data) clearError();
        stopLoader();
      }).catch( err => {
        console.log('Error in', err);
        stopLoader();
      });
  }

  return(
    <Button className="updateEvent magnifiBtn" onClick={updateEvent}>Update Event</Button>
  )
}

export default UpdateEvent;